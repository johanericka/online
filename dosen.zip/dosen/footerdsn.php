<?php
?>
<footer class="main-footer">
	<div class="float-right d-none d-sm-block">
		<b>Versi</b> 7.3
	</div>
	<strong>Menemukan error / pertanyaan ? laporkan <a href="https://wa.me/6281234302099" target="_blank">disini </a></strong>
</footer>